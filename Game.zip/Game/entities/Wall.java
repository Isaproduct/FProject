package Game.entities;

public class Wall extends StaticEntity {
    public Wall(int xPos, int yPos) {
        super(8, xPos, yPos);
    }
}

