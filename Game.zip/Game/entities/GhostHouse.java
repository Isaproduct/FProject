package Game.entities;


public class GhostHouse extends Wall {
    public GhostHouse(int xPos, int yPos) {
        super(xPos, yPos);
    }
}
